import React, { useState } from 'react';
import { PROTOCOL_STEPS } from '../data/protocolData';
import { Lock, ArrowRight, CheckCircle, AlertCircle, XCircle, ChevronRight, Eye } from 'lucide-react';

export const ProtocolSection: React.FC = () => {
  const [selectedStepId, setSelectedStepId] = useState<number>(1);
  const currentStep = PROTOCOL_STEPS.find(s => s.id === selectedStepId) || PROTOCOL_STEPS[0];

  return (
    <section id="protocol" className="py-24 border-t border-zinc-800/80 bg-[#0b0c10]/40 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-mono uppercase tracking-[0.25em] text-zinc-400">Mechanical Blueprint</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2">
            The 7-Step Execution Sequence
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base mt-3">
            We do not predict, guess, or hold open-ended hope. We follow a strict systematic order on every single execution. Click any step for detailed protocol schematics.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROTOCOL_STEPS.slice(0, 6).map((step) => {
            const isSelected = selectedStepId === step.id;
            return (
              <div
                key={step.id}
                onClick={() => setSelectedStepId(step.id)}
                className={`p-6 rounded-2xl bg-[#0b0c10] border transition-all duration-300 relative group cursor-pointer ${
                  isSelected
                    ? 'border-white/80 shadow-lg shadow-white/5 ring-1 ring-white/30'
                    : 'border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-mono font-bold text-sm transition-colors ${
                    isSelected ? 'bg-white text-black' : 'bg-[#171821] border border-zinc-700/80 text-white'
                  }`}>
                    {step.stepNumber}
                  </div>
                  <span className="text-[10px] font-mono tracking-wider px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">
                    {step.badge}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-zinc-100 group-hover:text-white transition-colors flex items-center justify-between">
                  <span>{step.title}</span>
                  <ChevronRight className={`w-4 h-4 text-zinc-500 transition-transform ${isSelected ? 'rotate-90 text-white' : ''}`} />
                </h3>
                <p className="text-xs font-mono text-amber-400/90 mt-1">{step.timing}</p>
                <p className="text-sm text-zinc-400 mt-3 leading-relaxed">
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Step 7 Highlight Banner */}
        <div
          onClick={() => setSelectedStepId(7)}
          className={`mt-8 p-7 rounded-2xl bg-gradient-to-r from-[#0b0c10] via-[#111217] to-[#0b0c10] border transition-all duration-300 flex flex-col md:flex-row items-center justify-between gap-6 cursor-pointer ${
            selectedStepId === 7 ? 'border-white/90 ring-1 ring-white/40' : 'border-zinc-700/80 hover:border-zinc-600'
          }`}
        >
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 rounded-2xl bg-white text-black flex items-center justify-center font-mono font-black text-xl flex-shrink-0">
              07
            </div>
            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-semibold">The Core Rule</span>
              <h4 className="text-xl font-bold text-white">Execute &amp; Close The Day</h4>
              <p className="text-sm text-zinc-400 mt-1">
                &bull; If Win: 1:3 RRR banked. Close charts.<br />
                &bull; If Loss: Invalidation triggered. Close charts and log it. We come back tomorrow.
              </p>
            </div>
          </div>
          <div className="flex-shrink-0 flex items-center gap-3">
            <span className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#171821] border border-zinc-700 text-xs font-mono text-zinc-300">
              <Lock className="w-4 h-4 text-amber-400" />
              2:00 AM Breakeven Lockout Mandatory
            </span>
            <span className="text-xs font-mono text-zinc-400 hidden sm:inline-flex items-center gap-1">
              Inspect Step <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>

        {/* Interactive Step Deep-Dive Inspector */}
        <div className="mt-10 p-6 sm:p-8 rounded-3xl bg-[#07080b] border border-zinc-700/80 shadow-2xl relative font-sans">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-zinc-800 gap-3">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 rounded-lg bg-white/10 text-white font-mono font-bold text-xs">
                STEP {currentStep.stepNumber} INSPECTION
              </span>
              <h4 className="text-lg font-bold text-white">{currentStep.title}</h4>
            </div>
            <span className="text-xs font-mono text-zinc-400 bg-[#111217] px-3 py-1 rounded-lg border border-zinc-800">
              Timing: {currentStep.timing}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#0b0c10] border border-zinc-800">
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-400 mb-1">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-semibold uppercase text-zinc-300">Mandatory Rule</span>
                </div>
                <p className="text-sm text-zinc-300 leading-relaxed">
                  {currentStep.deepDive.rule}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#0b0c10] border border-zinc-800">
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-400 mb-1">
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                  <span className="font-semibold uppercase text-zinc-300">Operational Action</span>
                </div>
                <p className="text-sm text-zinc-300 leading-relaxed">
                  {currentStep.deepDive.action}
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#0b0c10] border border-zinc-800">
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-400 mb-1">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-semibold uppercase text-zinc-300">Invalidation Threshold</span>
                </div>
                <p className="text-sm text-zinc-300 leading-relaxed">
                  {currentStep.deepDive.invalidation}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#140b0b] border border-red-900/40">
                <div className="flex items-center gap-2 text-xs font-mono text-red-400 mb-1">
                  <XCircle className="w-3.5 h-3.5 text-red-400" />
                  <span className="font-semibold uppercase text-red-300">Fatal Mistake to Avoid</span>
                </div>
                <p className="text-sm text-red-200/90 leading-relaxed">
                  {currentStep.deepDive.mistakeToAvoid}
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
